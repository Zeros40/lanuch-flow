
import { useToast } from '@/components/ui/use-toast';
import { LandingPageData } from './useLandingPageData';

export const useLandingPageActions = (
  pageData: LandingPageData,
  setPageData: (data: any) => void,
  setActiveTab: (tab: string) => void
) => {
  const { toast } = useToast();

  const handleCreateFromPrompt = (prompt: string) => {
    if (!prompt.trim()) {
      toast({
        title: 'Error',
        description: 'Please enter a prompt to generate your landing page.',
        variant: 'destructive'
      });
      return;
    }
    
    toast({
      title: 'Generating from Prompt',
      description: 'Your landing page is being created from the prompt...',
    });
    
    setTimeout(() => {
      setPageData(prev => ({
        ...prev,
        title: 'AI Generated Page',
        description: 'This page was generated from your prompt: ' + prompt.substring(0, 100) + '...',
        sections: [
          { type: 'hero', content: { title: 'AI Generated Hero', description: 'Generated content' } },
          { type: 'features', content: { title: 'Key Features', items: ['Feature 1', 'Feature 2', 'Feature 3'] } }
        ]
      }));
      setActiveTab('edit');
      toast({
        title: 'Landing Page Created',
        description: 'Your landing page has been generated from the prompt!',
      });
    }, 2000);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      toast({
        title: 'File Uploaded',
        description: `Processing ${file.name}...`,
      });
      
      setTimeout(() => {
        setPageData(prev => ({
          ...prev,
          title: `Page from ${file.name}`,
          description: `This page was created from the uploaded file: ${file.name}`,
          sections: [
            { type: 'hero', content: { title: 'Imported Content', description: 'Content from your file' } }
          ]
        }));
        setActiveTab('edit');
        toast({
          title: 'Landing Page Created',
          description: 'Your landing page has been generated from the uploaded file!',
        });
      }, 2000);
    }
  };

  const handleLanguageChange = (language: string) => {
    setPageData(prev => ({
      ...prev,
      primaryLanguage: language
    }));
    toast({
      title: 'Language Changed',
      description: `Your landing page language has been set to ${language}.`,
    });
  };

  const handleSave = () => {
    toast({
      title: 'Landing Page Saved',
      description: 'Your landing page has been saved successfully.',
    });
  };

  const handlePublish = () => {
    toast({
      title: 'Publishing',
      description: 'Your landing page is being published...',
    });
    
    setTimeout(() => {
      toast({
        title: 'Published!',
        description: 'Your landing page is now live.',
      });
    }, 1500);
  };

  return {
    handleCreateFromPrompt,
    handleFileUpload,
    handleLanguageChange,
    handleSave,
    handlePublish
  };
};
