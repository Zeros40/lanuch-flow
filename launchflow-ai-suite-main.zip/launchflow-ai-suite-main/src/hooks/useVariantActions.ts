
import { useToast } from '@/components/ui/use-toast';
import { LandingPageData } from './useLandingPageData';

export const useVariantActions = (
  pageData: LandingPageData,
  setPageData: (data: any) => void,
  setActiveTab: (tab: string) => void
) => {
  const { toast } = useToast();

  const handleCreateVariant = (name: string) => {
    if (!name.trim()) {
      toast({
        title: 'Error',
        description: 'Please enter a name for the variant.',
        variant: 'destructive'
      });
      return;
    }

    const newVariant = {
      id: `variant-${Date.now()}`,
      name,
      status: 'Active'
    };
    
    setPageData(prevData => ({
      ...prevData,
      variants: [...(prevData.variants || []), newVariant]
    }));

    toast({
      title: 'A/B Test Variant Created',
      description: `Variant "${name}" has been created and is ready for testing.`
    });
  };

  const handleDeleteVariant = (variantId: string) => {
    setPageData(prevData => ({
      ...prevData,
      variants: (prevData.variants || []).filter((v: any) => v.id !== variantId)
    }));

    toast({
      title: 'Variant Deleted',
      description: 'The test variant has been removed.'
    });
  };

  const handleEditVariant = (variantId: string) => {
    setActiveTab('edit');
    
    toast({
      title: 'Editing Variant',
      description: 'Now editing the selected variant.'
    });
  };

  const handleViewStats = (variantId: string) => {
    toast({
      title: 'Viewing Statistics',
      description: 'Displaying performance metrics for the selected variant.'
    });
  };

  return {
    handleCreateVariant,
    handleDeleteVariant,
    handleEditVariant,
    handleViewStats
  };
};
