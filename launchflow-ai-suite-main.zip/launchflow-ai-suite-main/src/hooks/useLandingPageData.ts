
import { useState } from 'react';

export interface LandingPageData {
  title: string;
  description: string;
  primaryLanguage: string;
  translations: Record<string, any>;
  sections: any[];
  customDomain: string;
  usePlatformDomain: boolean;
  variants: any[];
}

export const useLandingPageData = () => {
  const [pageData, setPageData] = useState<LandingPageData>({
    title: 'My Landing Page',
    description: 'Welcome to my professional landing page',
    primaryLanguage: 'english',
    translations: {},
    sections: [],
    customDomain: '',
    usePlatformDomain: true,
    variants: []
  });

  return { pageData, setPageData };
};
