
import { useToast } from '@/components/ui/use-toast';

export const useTemplateActions = () => {
  const { toast } = useToast();

  const handleTemplateSelect = (template: string) => {
    toast({
      title: 'Template Selected',
      description: `You've selected the ${template} template.`,
    });
  };

  return {
    handleTemplateSelect
  };
};
