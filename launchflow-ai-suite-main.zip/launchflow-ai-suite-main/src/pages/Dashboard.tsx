
import React from 'react';
import PageContainer from '@/components/Layout/PageContainer';
import WelcomeCard from '@/components/Dashboard/WelcomeCard';
import DashboardMetrics from '@/components/Dashboard/DashboardMetrics';
import ActivityFeed from '@/components/Dashboard/ActivityFeed';
import ClientList from '@/components/Clients/ClientList';
import ProjectList from '@/components/Projects/ProjectList';

const Dashboard = () => {
  return (
    <PageContainer
      title="Dashboard"
      subtitle="Overview of your business activities"
    >
      <div className="space-y-6">
        <WelcomeCard />
        <DashboardMetrics />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <ProjectList />
          </div>
          <div>
            <ActivityFeed />
          </div>
        </div>
        
        <ClientList />
      </div>
    </PageContainer>
  );
};

export default Dashboard;
