
import React from 'react';
import PageContainer from '@/components/Layout/PageContainer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';

const SettingsPage = () => {
  return (
    <PageContainer
      title="Settings"
      subtitle="Manage your account and application preferences"
    >
      <div className="space-y-6 animate-fade-in">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Settings</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="account">
              <TabsList className="mb-4">
                <TabsTrigger value="account">Account</TabsTrigger>
                <TabsTrigger value="notifications">Notifications</TabsTrigger>
                <TabsTrigger value="appearance">Appearance</TabsTrigger>
                <TabsTrigger value="billing">Billing</TabsTrigger>
              </TabsList>
              
              <TabsContent value="account" className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Profile Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Name</Label>
                      <Input id="name" defaultValue="Alex Morgan" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" defaultValue="alex@example.com" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="company">Company</Label>
                      <Input id="company" defaultValue="Morgan Consulting" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="role">Role</Label>
                      <Input id="role" defaultValue="Administrator" />
                    </div>
                  </div>
                  <Button>Save Changes</Button>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Change Password</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="current-password">Current Password</Label>
                      <Input id="current-password" type="password" />
                    </div>
                    <div></div>
                    <div className="space-y-2">
                      <Label htmlFor="new-password">New Password</Label>
                      <Input id="new-password" type="password" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirm-password">Confirm New Password</Label>
                      <Input id="confirm-password" type="password" />
                    </div>
                  </div>
                  <Button>Update Password</Button>
                </div>
              </TabsContent>
              
              <TabsContent value="notifications">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Email Notifications</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="new-client">New client notifications</Label>
                        <p className="text-sm text-muted-foreground">
                          Receive notifications when a new client is added
                        </p>
                      </div>
                      <Switch id="new-client" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="project-updates">Project updates</Label>
                        <p className="text-sm text-muted-foreground">
                          Receive notifications when projects are updated
                        </p>
                      </div>
                      <Switch id="project-updates" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="document-activity">Document activity</Label>
                        <p className="text-sm text-muted-foreground">
                          Receive notifications for document signatures and approvals
                        </p>
                      </div>
                      <Switch id="document-activity" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="marketing">Marketing emails</Label>
                        <p className="text-sm text-muted-foreground">
                          Receive updates about new features and promotions
                        </p>
                      </div>
                      <Switch id="marketing" />
                    </div>
                  </div>
                  <Button>Save Preferences</Button>
                </div>
              </TabsContent>
              
              <TabsContent value="appearance">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Appearance Settings</h3>
                  <p className="text-sm text-muted-foreground">
                    Customize how Business OS looks and feels
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="dark-mode">Dark mode</Label>
                        <p className="text-sm text-muted-foreground">
                          Toggle between light and dark mode
                        </p>
                      </div>
                      <Switch id="dark-mode" />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="compact-mode">Compact view</Label>
                        <p className="text-sm text-muted-foreground">
                          Show more content with reduced spacing
                        </p>
                      </div>
                      <Switch id="compact-mode" />
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="billing">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Billing Information</h3>
                  <div className="rounded-md border border-muted p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="font-medium">Pro Plan</p>
                        <p className="text-sm text-muted-foreground">$29/month</p>
                      </div>
                      <Badge variant="secondary">Active</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Your subscription renews on June 30, 2023
                    </p>
                    <div className="flex items-center gap-2">
                      <Button variant="outline">Change Plan</Button>
                      <Button variant="outline" className="text-destructive hover:text-destructive">
                        Cancel Subscription
                      </Button>
                    </div>
                  </div>
                  
                  <h3 className="text-lg font-medium">Payment Method</h3>
                  <div className="rounded-md border border-muted p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <div className="h-8 w-12 bg-gradient-blue rounded">
                          <div className="h-full w-full flex items-center justify-center font-bold text-white">
                            VISA
                          </div>
                        </div>
                        <div>
                          <p className="font-medium">Visa ending in 4242</p>
                          <p className="text-sm text-muted-foreground">Expires 04/25</p>
                        </div>
                      </div>
                    </div>
                    <Button variant="outline">Update Payment Method</Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  );
};

export default SettingsPage;
