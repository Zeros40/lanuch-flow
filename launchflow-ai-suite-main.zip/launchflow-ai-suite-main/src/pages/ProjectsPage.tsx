
import React from 'react';
import PageContainer from '@/components/Layout/PageContainer';
import ProjectList from '@/components/Projects/ProjectList';

const ProjectsPage = () => {
  return (
    <PageContainer
      title="Projects"
      subtitle="Track and manage your ongoing projects"
    >
      <ProjectList />
    </PageContainer>
  );
};

export default ProjectsPage;
