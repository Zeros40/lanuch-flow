
import React from 'react';
import PageContainer from '@/components/Layout/PageContainer';
import DocumentList from '@/components/Documents/DocumentList';

const DocumentsPage = () => {
  return (
    <PageContainer
      title="Documents"
      subtitle="Manage your proposals, contracts, and other documents"
    >
      <DocumentList />
    </PageContainer>
  );
};

export default DocumentsPage;
