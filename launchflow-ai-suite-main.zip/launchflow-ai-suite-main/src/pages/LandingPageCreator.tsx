
import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PageContainer from '@/components/Layout/PageContainer';
import CreateTabContent from '@/components/LandingPage/CreateTabContent';
import EditTabContent from '@/components/LandingPage/EditTabContent';
import PreviewTabContent from '@/components/LandingPage/PreviewTabContent';
import PublishTabContent from '@/components/LandingPage/PublishTabContent';
import { useLandingPageData } from '@/hooks/useLandingPageData';
import { useLandingPageActions } from '@/hooks/useLandingPageActions';
import { useVariantActions } from '@/hooks/useVariantActions';
import { useTemplateActions } from '@/hooks/useTemplateActions';

const LandingPageCreator = () => {
  const [activeTab, setActiveTab] = useState('create');
  const [selectedTemplate, setSelectedTemplate] = useState('clean');
  const { pageData, setPageData } = useLandingPageData();
  
  const { handleTemplateSelect } = useTemplateActions();
  const {
    handleCreateFromPrompt,
    handleFileUpload,
    handleLanguageChange,
    handleSave,
    handlePublish
  } = useLandingPageActions(pageData, setPageData, setActiveTab);
  
  const {
    handleCreateVariant,
    handleDeleteVariant,
    handleEditVariant,
    handleViewStats
  } = useVariantActions(pageData, setPageData, setActiveTab);

  const onTemplateSelect = (template: string) => {
    setSelectedTemplate(template);
    handleTemplateSelect(template);
  };

  return (
    <PageContainer
      title="Landing Page Creator"
      description="Create high-converting landing pages in minutes"
      className="space-y-6"
    >
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-4 mb-6">
          <TabsTrigger value="create">Create</TabsTrigger>
          <TabsTrigger value="edit">Edit</TabsTrigger>
          <TabsTrigger value="preview">Preview</TabsTrigger>
          <TabsTrigger value="publish">Publish</TabsTrigger>
        </TabsList>
        
        <TabsContent value="create">
          <CreateTabContent
            selectedTemplate={selectedTemplate}
            onSelectTemplate={onTemplateSelect}
            onStartWithTemplate={() => setActiveTab('edit')}
            onCreateFromPrompt={handleCreateFromPrompt}
            onFileUpload={handleFileUpload}
          />
        </TabsContent>

        <TabsContent value="edit">
          <EditTabContent
            pageData={pageData}
            setPageData={setPageData}
            selectedTemplate={selectedTemplate}
            onLanguageChange={handleLanguageChange}
            onSave={handleSave}
          />
        </TabsContent>

        <TabsContent value="preview">
          <PreviewTabContent
            pageData={pageData}
            selectedTemplate={selectedTemplate}
            onLanguageChange={handleLanguageChange}
            onEdit={() => setActiveTab('edit')}
            onContinueToPublish={() => setActiveTab('publish')}
          />
        </TabsContent>

        <TabsContent value="publish">
          <PublishTabContent
            pageData={pageData}
            setPageData={setPageData}
            onPublish={handlePublish}
            onCreateVariant={handleCreateVariant}
            onDeleteVariant={handleDeleteVariant}
            onEditVariant={handleEditVariant}
            onViewStats={handleViewStats}
          />
        </TabsContent>
      </Tabs>
    </PageContainer>
  );
};

export default LandingPageCreator;
