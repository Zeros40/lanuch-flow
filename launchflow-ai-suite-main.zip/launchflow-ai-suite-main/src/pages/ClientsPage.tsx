
import React from 'react';
import PageContainer from '@/components/Layout/PageContainer';
import ClientList from '@/components/Clients/ClientList';

const ClientsPage = () => {
  return (
    <PageContainer
      title="Clients"
      subtitle="Manage your client relationships"
    >
      <ClientList />
    </PageContainer>
  );
};

export default ClientsPage;
