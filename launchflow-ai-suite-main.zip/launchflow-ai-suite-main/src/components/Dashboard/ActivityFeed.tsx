
import React from 'react';
import { 
  FileText, User, FolderKanban, Mail, Check, 
  FileCheck, PenSquare, Calendar 
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface ActivityItemProps {
  icon: React.ReactNode;
  iconBg?: string;
  title: React.ReactNode;
  timestamp: string;
}

const ActivityItem: React.FC<ActivityItemProps> = ({ 
  icon, 
  iconBg = "bg-primary/10", 
  title, 
  timestamp 
}) => {
  return (
    <div className="flex items-start gap-3 pb-4 mb-4 border-b last:border-0 last:mb-0 last:pb-0">
      <div className={cn("p-2 rounded-full flex-shrink-0", iconBg)}>
        {icon}
      </div>
      <div>
        <p className="text-sm">{title}</p>
        <p className="text-xs text-muted-foreground mt-0.5">{timestamp}</p>
      </div>
    </div>
  );
};

const ActivityFeed = () => {
  return (
    <Card className="h-full animate-fade-in">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent className="overflow-auto" style={{ maxHeight: '400px' }}>
        <ActivityItem 
          icon={<FileText className="h-4 w-4 text-primary" />}
          title={<>
            New proposal <span className="font-medium">Marketing Strategy</span> created
          </>}
          timestamp="Just now"
        />
        <ActivityItem 
          icon={<FolderKanban className="h-4 w-4 text-white" />}
          iconBg="bg-gradient-blue"
          title={<>
            Project <span className="font-medium">Website Redesign</span> status updated to <span className="font-medium">In Progress</span>
          </>}
          timestamp="2 hours ago"
        />
        <ActivityItem 
          icon={<User className="h-4 w-4 text-white" />}
          iconBg="bg-gradient-purple"
          title={<>
            <span className="font-medium">Sarah Johnson</span> invited to client portal
          </>}
          timestamp="4 hours ago"
        />
        <ActivityItem 
          icon={<PenSquare className="h-4 w-4 text-primary" />}
          title={<>
            Contract <span className="font-medium">Quarterly Services</span> updated
          </>}
          timestamp="Yesterday"
        />
        <ActivityItem 
          icon={<FileCheck className="h-4 w-4 text-primary" />}
          title={<>
            Document <span className="font-medium">Project Brief</span> approved by client
          </>}
          timestamp="Yesterday"
        />
        <ActivityItem 
          icon={<Mail className="h-4 w-4 text-primary" />}
          title={<>
            <span className="font-medium">5 emails</span> sent to prospect clients
          </>}
          timestamp="2 days ago"
        />
        <ActivityItem 
          icon={<Calendar className="h-4 w-4 text-primary" />}
          title={<>
            Meeting scheduled with <span className="font-medium">Acme Corp</span>
          </>}
          timestamp="3 days ago"
        />
        <ActivityItem 
          icon={<Check className="h-4 w-4 text-primary" />}
          title={<>
            <span className="font-medium">Q3 Planning</span> task completed
          </>}
          timestamp="4 days ago"
        />
      </CardContent>
    </Card>
  );
};

export default ActivityFeed;
