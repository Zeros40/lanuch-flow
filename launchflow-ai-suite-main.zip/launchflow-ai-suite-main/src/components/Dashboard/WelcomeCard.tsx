
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';

const WelcomeCard = () => {
  return (
    <Card className="overflow-hidden border-none shadow-lg animate-fade-in">
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-card" />
        <CardContent className="relative p-6">
          <div className="flex justify-between items-start">
            <div className="text-white max-w-lg">
              <h2 className="text-xl font-bold mb-2">Welcome back, Alex!</h2>
              <p className="text-white/90 text-sm mb-4">
                You have 5 tasks due this week and 3 client proposals waiting for review.
                Here's what needs your attention today.
              </p>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" className="bg-white text-primary hover:bg-white/90">
                  Review Proposals
                </Button>
                <Button size="sm" variant="outline" className="border-white/30 text-white hover:bg-white/10">
                  View Tasks
                </Button>
              </div>
            </div>
            <div className="hidden md:flex flex-col items-center gap-2 text-white">
              <div className="text-sm font-medium text-white/80">Quick Links</div>
              <div className="flex flex-col gap-1.5">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-white hover:bg-white/10 justify-start gap-2"
                >
                  <span>New Client</span>
                  <ArrowRight className="h-3 w-3 opacity-70" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-white hover:bg-white/10 justify-start gap-2"
                >
                  <span>New Project</span>
                  <ArrowRight className="h-3 w-3 opacity-70" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-white hover:bg-white/10 justify-start gap-2"
                >
                  <span>New Document</span>
                  <ArrowRight className="h-3 w-3 opacity-70" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </div>
    </Card>
  );
};

export default WelcomeCard;
