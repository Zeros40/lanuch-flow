
import React from 'react';
import { ArrowUpRight, ArrowDownRight, Users, Clock, Calendar, FileText } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface MetricCardProps {
  title: string;
  value: string;
  change?: {
    value: number;
    isPositive: boolean;
  };
  icon: React.ElementType;
  iconClass?: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ 
  title, 
  value, 
  change, 
  icon: Icon,
  iconClass
}) => {
  return (
    <Card className="card-hover">
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <h3 className="text-2xl font-bold mt-1">{value}</h3>
            {change && (
              <div className="flex items-center mt-1">
                <span className={cn(
                  "text-xs font-medium",
                  change.isPositive ? "text-green-600" : "text-red-600"
                )}>
                  {change.isPositive ? '+' : ''}{change.value}%
                </span>
                {change.isPositive ? (
                  <ArrowUpRight className="h-3 w-3 ml-0.5 text-green-600" />
                ) : (
                  <ArrowDownRight className="h-3 w-3 ml-0.5 text-red-600" />
                )}
                <span className="text-xs text-muted-foreground ml-1.5">vs last month</span>
              </div>
            )}
          </div>
          <div className={cn(
            "p-2 rounded-lg",
            iconClass || "bg-primary/10"
          )}>
            <Icon className={cn(
              "h-5 w-5",
              iconClass ? "text-white" : "text-primary"  
            )} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const DashboardMetrics = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 animate-fade-in">
      <MetricCard
        title="Active Clients"
        value="28"
        change={{ value: 12, isPositive: true }}
        icon={Users}
        iconClass="bg-gradient-blue"
      />
      <MetricCard
        title="Ongoing Projects"
        value="32"
        change={{ value: 8, isPositive: true }}
        icon={Calendar}
        iconClass="bg-gradient-purple"
      />
      <MetricCard
        title="Hours Logged"
        value="184"
        change={{ value: 3, isPositive: false }}
        icon={Clock}
      />
      <MetricCard
        title="Documents"
        value="46"
        change={{ value: 24, isPositive: true }}
        icon={FileText}
      />
    </div>
  );
};

export default DashboardMetrics;
