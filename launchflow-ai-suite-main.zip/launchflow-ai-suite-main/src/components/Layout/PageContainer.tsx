
import React from 'react';
import Sidebar from './Sidebar';
import Navbar from './Navbar';

interface PageContainerProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  className?: string;
  description?: string;
}

const PageContainer: React.FC<PageContainerProps> = ({ 
  children, 
  title, 
  subtitle,
  className = "",
  description
}) => {
  return (
    <div className="min-h-screen flex bg-background">
      <Sidebar />
      <div className="flex-1 ml-64">
        <Navbar />
        <main className={`p-6 ${className}`}>
          {(title || subtitle || description) && (
            <div className="mb-6">
              {title && <h1 className="text-2xl font-bold">{title}</h1>}
              {subtitle && <p className="text-muted-foreground mt-1">{subtitle}</p>}
              {description && <p className="text-muted-foreground mt-1">{description}</p>}
            </div>
          )}
          {children}
        </main>
      </div>
    </div>
  );
};

export default PageContainer;
