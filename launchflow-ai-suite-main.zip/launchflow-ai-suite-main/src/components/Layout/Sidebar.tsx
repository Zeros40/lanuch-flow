
import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  FolderKanban, 
  FileText, 
  Settings, 
  HelpCircle,
  Star
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const menuItems = [
  { 
    name: 'Dashboard', 
    path: '/dashboard', 
    icon: LayoutDashboard 
  },
  { 
    name: 'Clients', 
    path: '/clients', 
    icon: Users 
  },
  { 
    name: 'Projects', 
    path: '/projects', 
    icon: FolderKanban 
  },
  { 
    name: 'Documents', 
    path: '/documents', 
    icon: FileText 
  },
  { 
    name: 'Settings', 
    path: '/settings', 
    icon: Settings 
  },
];

const Sidebar = () => {
  return (
    <div className="h-screen flex flex-col w-64 bg-sidebar text-sidebar-foreground fixed left-0 top-0 z-30">
      <div className="h-16 flex items-center px-6 border-b border-sidebar-border">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-md bg-gradient-card flex items-center justify-center">
            <Star className="h-5 w-5 text-white" />
          </div>
          <span className="text-lg font-semibold text-white">Business OS</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-4">
        <nav className="px-3 space-y-1.5">
          {menuItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                isActive 
                  ? "bg-sidebar-accent text-white" 
                  : "text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-white"
              )}
            >
              <item.icon className="h-5 w-5" />
              <span>{item.name}</span>
            </NavLink>
          ))}
        </nav>
        
        <div className="mt-6 px-6">
          <div className="rounded-lg bg-sidebar-accent p-4">
            <div className="flex items-center gap-3 mb-3">
              <HelpCircle className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">Need help?</span>
            </div>
            <p className="text-xs text-sidebar-foreground/80 mb-3">
              Contact our support team for guidance on using the platform effectively.
            </p>
            <Button 
              size="sm" 
              className="w-full bg-sidebar-primary hover:bg-sidebar-primary/90 text-white"
            >
              Contact Support
            </Button>
          </div>
        </div>
      </div>
      
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="bg-sidebar-accent h-10 w-10 rounded-full flex items-center justify-center text-white">
            AM
          </div>
          <div>
            <div className="text-sm font-medium">Alex Morgan</div>
            <div className="text-xs text-sidebar-foreground/70">alex@example.com</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
