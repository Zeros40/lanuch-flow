
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PencilIcon, RocketIcon } from 'lucide-react';
import LanguageSelector from './LanguageSelector';
import LandingPagePreview from './LandingPagePreview';

interface PreviewTabContentProps {
  pageData: any;
  selectedTemplate: string;
  onLanguageChange: (language: string) => void;
  onEdit: () => void;
  onContinueToPublish: () => void;
}

const PreviewTabContent: React.FC<PreviewTabContentProps> = ({
  pageData,
  selectedTemplate,
  onLanguageChange,
  onEdit,
  onContinueToPublish
}) => {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Landing Page Preview</CardTitle>
          <div className="flex items-center gap-2">
            <Select defaultValue="desktop">
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="Preview Mode" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="desktop">Desktop</SelectItem>
                <SelectItem value="tablet">Tablet</SelectItem>
                <SelectItem value="mobile">Mobile</SelectItem>
              </SelectContent>
            </Select>
            <LanguageSelector onLanguageChange={onLanguageChange} />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="border rounded-md bg-background">
          <div className="p-2 border-b flex items-center gap-2">
            <div className="flex gap-1">
              <span className="w-3 h-3 rounded-full bg-red-500"></span>
              <span className="w-3 h-3 rounded-full bg-yellow-500"></span>
              <span className="w-3 h-3 rounded-full bg-green-500"></span>
            </div>
            <div className="flex-1 bg-muted h-6 rounded flex items-center justify-center text-xs text-muted-foreground">
              {pageData.customDomain || 'your-landing-page.domain.com'}
            </div>
          </div>
          <div className="p-4 min-h-[500px]">
            <LandingPagePreview 
              pageData={pageData} 
              selectedTemplate={selectedTemplate}
            />
          </div>
        </div>
        <div className="flex justify-end gap-4 mt-4">
          <Button variant="outline" onClick={onEdit}>
            <PencilIcon className="mr-2" />
            Edit Page
          </Button>
          <Button onClick={onContinueToPublish}>
            <RocketIcon className="mr-2" />
            Continue to Publish
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default PreviewTabContent;
