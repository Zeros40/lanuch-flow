
import React, { useState } from 'react';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PencilIcon, PlusIcon, TrashIcon, ChartLineIcon } from 'lucide-react';

interface ABTestingVariantsProps {
  pageData: any;
  onCreateVariant: (name: string) => void;
  onDeleteVariant: (variantId: string) => void;
  onEditVariant: (variantId: string) => void;
  onViewStats: (variantId: string) => void;
}

const ABTestingVariants: React.FC<ABTestingVariantsProps> = ({
  pageData,
  onCreateVariant,
  onDeleteVariant,
  onEditVariant,
  onViewStats
}) => {
  const [newVariantName, setNewVariantName] = useState<string>('');

  const handleCreateVariant = () => {
    if (newVariantName.trim()) {
      onCreateVariant(newVariantName);
      setNewVariantName('');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-end gap-2">
        <div className="flex-1">
          <Input
            placeholder="Variant name (e.g., Button Color Test)"
            value={newVariantName}
            onChange={(e) => setNewVariantName(e.target.value)}
          />
        </div>
        <Button onClick={handleCreateVariant}>
          <PlusIcon className="mr-2 h-4 w-4" />
          Add Variant
        </Button>
      </div>

      {pageData.variants && pageData.variants.length > 0 ? (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Variant</TableHead>
              <TableHead>Traffic Split</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell className="font-medium">Original (Control)</TableCell>
              <TableCell>{pageData.variants.length > 0 ? `${Math.floor(100 / (pageData.variants.length + 1))}%` : '100%'}</TableCell>
              <TableCell>Active</TableCell>
              <TableCell className="text-right">
                <Button variant="outline" size="sm" className="mr-2">
                  Edit
                </Button>
              </TableCell>
            </TableRow>
            {pageData.variants.map((variant: any) => (
              <TableRow key={variant.id}>
                <TableCell className="font-medium">{variant.name}</TableCell>
                <TableCell>{`${Math.floor(100 / (pageData.variants.length + 1))}%`}</TableCell>
                <TableCell>{variant.status || 'Active'}</TableCell>
                <TableCell className="text-right space-x-1">
                  <Button variant="ghost" size="sm" onClick={() => onEditVariant(variant.id)}>
                    <PencilIcon className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => onViewStats(variant.id)}>
                    <ChartLineIcon className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => onDeleteVariant(variant.id)}>
                    <TrashIcon className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      ) : (
        <div className="text-center py-8 border border-dashed rounded-md bg-muted/40">
          <p className="text-muted-foreground">No variants created yet</p>
          <p className="text-sm text-muted-foreground">Create variants to test different versions of your landing page</p>
        </div>
      )}
    </div>
  );
};

export default ABTestingVariants;
