
import React from 'react';

interface LandingPagePreviewProps {
  pageData: any;
  selectedTemplate: string;
}

const LandingPagePreview: React.FC<LandingPagePreviewProps> = ({ 
  pageData, 
  selectedTemplate 
}) => {
  const renderTemplate = () => {
    switch (selectedTemplate) {
      case 'bold':
        return <BoldTemplate pageData={pageData} />;
      case 'professional':
        return <ProfessionalTemplate pageData={pageData} />;
      case 'creative':
        return <CreativeTemplate pageData={pageData} />;
      case 'clean':
      default:
        return <CleanTemplate pageData={pageData} />;
    }
  };

  return (
    <div className="landing-page-preview min-h-[400px]">
      {renderTemplate()}
    </div>
  );
};

const CleanTemplate: React.FC<{ pageData: any }> = ({ pageData }) => {
  return (
    <div className="space-y-8 p-6">
      <header className="text-center py-12 space-y-4">
        <h1 className="text-4xl font-bold text-gray-900">{pageData.title || 'Welcome to Our Landing Page'}</h1>
        <p className="text-gray-600 text-lg max-w-2xl mx-auto">
          {pageData.description || 'A professional landing page to showcase your product or service'}
        </p>
        <div className="flex justify-center gap-4 pt-6">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
            Get Started
          </button>
          <button className="border border-gray-300 bg-white text-gray-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-50 transition-colors">
            Learn More
          </button>
        </div>
      </header>

      {pageData.sections && pageData.sections.length > 0 ? (
        pageData.sections.map((section: any, index: number) => (
          <div key={index} className="py-16">
            {section.type === 'hero' && (
              <div className="text-center">
                <h2 className="text-3xl font-bold mb-4">{section.content?.title || 'Hero Section'}</h2>
                <p className="text-gray-600">{section.content?.description || 'Hero description'}</p>
              </div>
            )}
            {section.type === 'features' && (
              <div className="text-center">
                <h2 className="text-3xl font-bold mb-8">Features</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {[1, 2, 3].map((item) => (
                    <div key={item} className="p-6 bg-gray-50 rounded-lg">
                      <h3 className="text-xl font-semibold mb-2">Feature {item}</h3>
                      <p className="text-gray-600">Feature description goes here</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {section.type === 'testimonials' && (
              <div className="text-center">
                <h2 className="text-3xl font-bold mb-8">What Our Customers Say</h2>
                <div className="bg-gray-50 p-8 rounded-lg max-w-2xl mx-auto">
                  <p className="text-gray-600 italic mb-4">"This is an amazing product that has transformed our business!"</p>
                  <p className="font-semibold">- Happy Customer</p>
                </div>
              </div>
            )}
            {section.type === 'cta' && (
              <div className="bg-blue-600 text-white py-16 rounded-lg text-center">
                <h2 className="text-3xl font-bold mb-6">Ready to get started?</h2>
                <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
                  Sign Up Now
                </button>
              </div>
            )}
          </div>
        ))
      ) : (
        <div className="py-16 text-center text-gray-500">
          <p>Add sections to see your content here</p>
        </div>
      )}
    </div>
  );
};

const BoldTemplate: React.FC<{ pageData: any }> = ({ pageData }) => {
  return (
    <div className="space-y-8">
      <header className="bg-gradient-to-r from-purple-600 to-pink-600 text-white py-16 px-8 rounded-lg text-center space-y-4">
        <h1 className="text-5xl font-extrabold">{pageData.title || 'Bold & Eye-Catching'}</h1>
        <p className="text-xl max-w-2xl mx-auto opacity-90">
          {pageData.description || 'Make a strong impression with this vibrant landing page design'}
        </p>
        <div className="flex justify-center gap-4 pt-6">
          <button className="bg-white text-purple-600 px-8 py-3 rounded-lg font-bold hover:bg-gray-100 transition-colors">
            Start Now
          </button>
          <button className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg font-bold hover:bg-white hover:text-purple-600 transition-colors">
            Learn More
          </button>
        </div>
      </header>

      <div className="text-center py-16">
        <h2 className="text-3xl font-bold mb-8">Why Choose Us?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[1, 2, 3].map((item) => (
            <div key={item} className="p-6 border-2 border-purple-200 rounded-lg hover:border-purple-400 transition-colors">
              <h3 className="text-xl font-bold mb-2 text-purple-600">Benefit {item}</h3>
              <p className="text-gray-600">Amazing benefit description</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const ProfessionalTemplate: React.FC<{ pageData: any }> = ({ pageData }) => {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h1 className="text-4xl font-bold text-gray-900">
            {pageData.title || 'Professional Solutions'}
          </h1>
          <p className="text-gray-600 text-lg">
            {pageData.description || 'Corporate-focused design with a professional appearance for serious business applications'}
          </p>
          <div className="space-y-4">
            <button className="bg-blue-900 text-white px-8 py-3 rounded-sm font-semibold hover:bg-blue-800 transition-colors">
              Contact Us
            </button>
            <p className="text-sm text-gray-500">Trusted by 500+ companies worldwide</p>
          </div>
        </div>
        <div className="bg-gray-100 rounded-lg h-80 flex items-center justify-center">
          <p className="text-gray-500">Professional Image Placeholder</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 py-16">
        {['Reliability', 'Security', 'Support', 'Results'].map((feature) => (
          <div key={feature} className="text-center">
            <div className="w-16 h-16 bg-blue-900 rounded-full mx-auto mb-4 flex items-center justify-center">
              <span className="text-white font-bold">{feature[0]}</span>
            </div>
            <h3 className="font-semibold mb-2">{feature}</h3>
            <p className="text-gray-600 text-sm">Enterprise-grade {feature.toLowerCase()}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

const CreativeTemplate: React.FC<{ pageData: any }> = ({ pageData }) => {
  return (
    <div className="space-y-8 relative overflow-hidden">
      <div className="absolute -top-20 -right-20 w-40 h-40 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full opacity-20"></div>
      <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-gradient-to-tr from-green-400 to-blue-500 rounded-full opacity-20"></div>
      
      <header className="py-16 relative z-10">
        <div className="text-center space-y-6">
          <h1 className="text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600">
            {pageData.title || 'Creative & Unique'}
          </h1>
          <p className="text-gray-600 text-xl max-w-2xl mx-auto">
            {pageData.description || 'Stand out with this creative and artistic landing page design that captures attention'}
          </p>
          <div className="flex justify-center gap-4 pt-6">
            <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-3 rounded-full font-bold hover:shadow-lg transition-all transform hover:scale-105">
              Get Inspired
            </button>
            <button className="border-2 border-gray-300 text-gray-700 px-8 py-3 rounded-full font-bold hover:border-purple-600 hover:text-purple-600 transition-colors">
              View Portfolio
            </button>
          </div>
        </div>
      </header>

      <div className="relative z-10 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Creative Process</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {['Ideate', 'Create', 'Inspire'].map((step, index) => (
            <div key={step} className="relative">
              <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow border border-gray-100">
                <div className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-br from-purple-600 to-pink-600 mb-4">
                  0{index + 1}
                </div>
                <h3 className="text-xl font-bold mb-2">{step}</h3>
                <p className="text-gray-600">Transform ideas into beautiful, functional designs</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LandingPagePreview;
