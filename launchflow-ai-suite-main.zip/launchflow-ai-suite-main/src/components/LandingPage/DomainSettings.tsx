
import React from 'react';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { GlobeIcon, SearchIcon } from 'lucide-react';

interface DomainSettingsProps {
  pageData: any;
  setPageData: (data: any) => void;
}

const DomainSettings: React.FC<DomainSettingsProps> = ({ 
  pageData, 
  setPageData 
}) => {
  const handleDomainTypeChange = (value: string) => {
    setPageData({
      ...pageData,
      usePlatformDomain: value === 'platform'
    });
  };

  const handleCustomDomainChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPageData({
      ...pageData,
      customDomain: e.target.value
    });
  };

  const checkDomainAvailability = () => {
    // This would check domain availability in a real implementation
    alert('Domain availability checking would happen here');
  };

  return (
    <div className="space-y-6">
      <RadioGroup 
        defaultValue={pageData.usePlatformDomain ? 'platform' : 'custom'}
        onValueChange={handleDomainTypeChange}
      >
        <div className="flex items-start space-x-2 mb-4">
          <RadioGroupItem value="platform" id="platform" />
          <div className="grid gap-1.5">
            <Label htmlFor="platform" className="font-medium">Use Platform Domain</Label>
            <p className="text-sm text-muted-foreground">
              Host your landing page on our domain (yourname.launchflow.app)
            </p>
            {pageData.usePlatformDomain && (
              <div className="mt-2 flex items-center gap-2">
                <Input 
                  placeholder="your-page-name" 
                  className="max-w-[200px]" 
                />
                <span className="text-muted-foreground">.launchflow.app</span>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex items-start space-x-2">
          <RadioGroupItem value="custom" id="custom" />
          <div className="grid gap-1.5 flex-1">
            <Label htmlFor="custom" className="font-medium">Connect Custom Domain</Label>
            <p className="text-sm text-muted-foreground">
              Use your own domain name for your landing page
            </p>
            {!pageData.usePlatformDomain && (
              <div className="mt-2 space-y-4">
                <div className="flex gap-2">
                  <Input 
                    placeholder="yourdomain.com" 
                    value={pageData.customDomain}
                    onChange={handleCustomDomainChange}
                  />
                  <Button variant="outline" onClick={checkDomainAvailability}>
                    <SearchIcon className="h-4 w-4 mr-1" />
                    Check
                  </Button>
                </div>
                
                <Alert>
                  <GlobeIcon className="h-4 w-4" />
                  <AlertDescription>
                    You'll need to update your DNS settings to connect your domain. 
                    We'll provide instructions after publishing.
                  </AlertDescription>
                </Alert>
              </div>
            )}
          </div>
        </div>
      </RadioGroup>
    </div>
  );
};

export default DomainSettings;
