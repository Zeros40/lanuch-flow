
import React from 'react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { 
  TextIcon,
  ImageIcon,
  LayoutTemplateIcon,
  Grid2X2Icon,
  PencilIcon,
  PlusIcon
} from 'lucide-react';

interface LandingPageEditorProps {
  pageData: any;
  setPageData: (data: any) => void;
  selectedTemplate: string;
}

const LandingPageEditor: React.FC<LandingPageEditorProps> = ({ 
  pageData, 
  setPageData,
  selectedTemplate 
}) => {
  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPageData({
      ...pageData,
      title: e.target.value
    });
  };

  const handleDescriptionChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setPageData({
      ...pageData,
      description: e.target.value
    });
  };

  const addSection = (type: string) => {
    setPageData({
      ...pageData,
      sections: [...pageData.sections, { type, content: {} }]
    });
  };

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <div>
          <Label htmlFor="page-title">Page Title</Label>
          <Input
            id="page-title"
            value={pageData.title}
            onChange={handleTitleChange}
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="page-description">Page Description</Label>
          <Textarea
            id="page-description"
            value={pageData.description}
            onChange={handleDescriptionChange}
            className="mt-1"
          />
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-base font-medium mb-3">Page Sections</h3>
        <Accordion type="multiple" className="mb-6">
          {pageData.sections.length > 0 ? (
            pageData.sections.map((section: any, index: number) => (
              <AccordionItem key={index} value={`section-${index}`}>
                <AccordionTrigger>
                  {section.type === 'hero' && 'Hero Section'}
                  {section.type === 'features' && 'Features Section'}
                  {section.type === 'testimonials' && 'Testimonials Section'}
                  {section.type === 'cta' && 'Call to Action Section'}
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-3 py-2">
                    <div>
                      <Label>Section Title</Label>
                      <Input className="mt-1" />
                    </div>
                    <div>
                      <Label>Content</Label>
                      <Textarea className="mt-1 min-h-[100px]" />
                    </div>
                    <div className="flex justify-end">
                      <Button variant="outline" size="sm" className="mr-2">
                        <PencilIcon className="h-4 w-4 mr-1" /> Edit
                      </Button>
                      <Button variant="destructive" size="sm">
                        Remove
                      </Button>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))
          ) : (
            <div className="text-center py-8 border border-dashed rounded-md bg-muted/40">
              <p className="text-muted-foreground">No sections added yet</p>
              <p className="text-sm text-muted-foreground">Use the buttons below to add sections to your page</p>
            </div>
          )}
        </Accordion>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
          <Button 
            variant="outline" 
            className="flex flex-col h-auto py-4" 
            onClick={() => addSection('hero')}
          >
            <LayoutTemplateIcon className="h-5 w-5 mb-1" />
            <span>Hero Section</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex flex-col h-auto py-4"
            onClick={() => addSection('features')}
          >
            <Grid2X2Icon className="h-5 w-5 mb-1" />
            <span>Features</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex flex-col h-auto py-4"
            onClick={() => addSection('testimonials')}
          >
            <TextIcon className="h-5 w-5 mb-1" />
            <span>Testimonials</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex flex-col h-auto py-4"
            onClick={() => addSection('cta')}
          >
            <PlusIcon className="h-5 w-5 mb-1" />
            <span>Call to Action</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default LandingPageEditor;
