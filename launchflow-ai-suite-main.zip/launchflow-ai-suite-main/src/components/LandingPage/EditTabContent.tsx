
import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import LandingPageEditor from './LandingPageEditor';
import LanguageSelector from './LanguageSelector';

interface EditTabContentProps {
  pageData: any;
  setPageData: (data: any) => void;
  selectedTemplate: string;
  onLanguageChange: (language: string) => void;
  onSave: () => void;
}

const EditTabContent: React.FC<EditTabContentProps> = ({
  pageData,
  setPageData,
  selectedTemplate,
  onLanguageChange,
  onSave
}) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Page Editor</CardTitle>
              <LanguageSelector onLanguageChange={onLanguageChange} />
            </div>
          </CardHeader>
          <CardContent>
            <LandingPageEditor 
              pageData={pageData} 
              setPageData={setPageData} 
              selectedTemplate={selectedTemplate}
            />
          </CardContent>
        </Card>
      </div>
      <div>
        <Card className="sticky top-4">
          <CardHeader>
            <CardTitle>Tools & Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label>SEO Settings</Label>
              <Button variant="outline" size="sm" className="w-full">
                Configure SEO
              </Button>
            </div>
            <div className="space-y-2">
              <Label>Conversion Elements</Label>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm">Add Form</Button>
                <Button variant="outline" size="sm">Add CTA</Button>
                <Button variant="outline" size="sm">Add Timer</Button>
                <Button variant="outline" size="sm">Add Social</Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Analytics</Label>
              <Button variant="outline" size="sm" className="w-full">
                Setup Tracking
              </Button>
            </div>

            <Button 
              className="w-full" 
              onClick={onSave}
            >
              Save Changes
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default EditTabContent;
