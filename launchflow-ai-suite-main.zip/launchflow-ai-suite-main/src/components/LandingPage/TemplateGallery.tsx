
import React from 'react';
import { AspectRatio } from '@/components/ui/aspect-ratio';

interface TemplateGalleryProps {
  selectedTemplate: string;
  onSelectTemplate: (template: string) => void;
}

const templates = [
  {
    id: 'clean',
    name: 'Clean & Modern',
    description: 'A clean, modern design with plenty of whitespace',
    image: '/placeholder.svg'
  },
  {
    id: 'bold',
    name: 'Bold & Vibrant',
    description: 'Eye-catching design with strong colors',
    image: '/placeholder.svg'
  },
  {
    id: 'professional',
    name: 'Professional',
    description: 'Corporate-focused design with serious tone',
    image: '/placeholder.svg'
  },
  {
    id: 'creative',
    name: 'Creative',
    description: 'Unique layouts for creative professionals',
    image: '/placeholder.svg'
  }
];

const TemplateGallery: React.FC<TemplateGalleryProps> = ({ selectedTemplate, onSelectTemplate }) => {
  return (
    <div className="grid grid-cols-2 gap-3">
      {templates.map((template) => (
        <div 
          key={template.id}
          onClick={() => onSelectTemplate(template.id)}
          className={`cursor-pointer rounded-lg border p-2 transition-all hover:shadow-md ${
            selectedTemplate === template.id ? 'border-primary ring-2 ring-primary/20' : 'border-border'
          }`}
        >
          <AspectRatio ratio={16 / 9} className="bg-muted mb-2 rounded overflow-hidden">
            <img 
              src={template.image} 
              alt={template.name} 
              className="object-cover w-full h-full"
            />
          </AspectRatio>
          <h4 className="font-medium text-sm">{template.name}</h4>
          <p className="text-xs text-muted-foreground">{template.description}</p>
        </div>
      ))}
    </div>
  );
};

export default TemplateGallery;
