
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, XAxis, YAxis } from 'recharts';

interface ABTestingResultsProps {
  data: any[];
}

const ABTestingResults: React.FC<ABTestingResultsProps> = ({ data }) => {
  const chartConfig = {
    views: {
      label: "Page Views",
      color: "#2563eb"
    },
    conversions: {
      label: "Conversions",
      color: "#10b981"
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>A/B Testing Results</CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer 
          className="h-[300px]" 
          config={chartConfig}
        >
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="name" />
            <YAxis />
            <ChartTooltip
              content={<ChartTooltipContent />}
            />
            <Legend />
            <Bar dataKey="views" name="Views" fill="var(--color-views)" radius={[4, 4, 0, 0]} />
            <Bar dataKey="conversions" name="Conversions" fill="var(--color-conversions)" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ChartContainer>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
          {data.map((item, index) => (
            <div key={index} className="border rounded-md p-4">
              <p className="font-medium">{item.name}</p>
              <div className="mt-2 space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Views:</span>
                  <span className="font-medium">{item.views.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Conversions:</span>
                  <span className="font-medium">{item.conversions.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Rate:</span>
                  <span className="font-medium">{((item.conversions / item.views) * 100).toFixed(2)}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default ABTestingResults;
