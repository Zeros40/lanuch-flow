
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { PencilIcon, SearchIcon, UploadIcon, LayoutTemplateIcon } from 'lucide-react';
import TemplateGallery from './TemplateGallery';

interface CreateTabContentProps {
  selectedTemplate: string;
  onSelectTemplate: (template: string) => void;
  onStartWithTemplate: () => void;
  onCreateFromPrompt: (prompt: string) => void;
  onFileUpload: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

const CreateTabContent: React.FC<CreateTabContentProps> = ({
  selectedTemplate,
  onSelectTemplate,
  onStartWithTemplate,
  onCreateFromPrompt,
  onFileUpload
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Start With a Template</CardTitle>
          <CardDescription>Choose a professionally designed template to get started quickly</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <TemplateGallery 
            selectedTemplate={selectedTemplate} 
            onSelectTemplate={onSelectTemplate} 
          />
          <Button 
            className="w-full mt-4" 
            onClick={onStartWithTemplate}
          >
            <LayoutTemplateIcon className="mr-2" />
            Use Selected Template
          </Button>
        </CardContent>
      </Card>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Create from Prompt</CardTitle>
            <CardDescription>Let AI generate your landing page from a description</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea 
              placeholder="Describe your ideal landing page, target audience, and goals..." 
              className="min-h-[120px]" 
              id="prompt-input"
            />
            <Button 
              className="w-full" 
              onClick={() => onCreateFromPrompt(
                (document.getElementById('prompt-input') as HTMLTextAreaElement).value
              )}
            >
              <PencilIcon className="mr-2" />
              Generate from Prompt
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Import Content</CardTitle>
            <CardDescription>Create from existing materials</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="file-upload">Upload PDF or Document</Label>
                <div className="mt-2">
                  <Input 
                    id="file-upload" 
                    type="file" 
                    accept=".pdf,.doc,.docx" 
                    className="cursor-pointer"
                    onChange={onFileUpload}
                  />
                </div>
              </div>
              <div>
                <Label>Import from Proposals</Label>
                <Button variant="outline" className="w-full mt-2">
                  <SearchIcon className="mr-2" />
                  Browse Proposals
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CreateTabContent;
