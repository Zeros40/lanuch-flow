
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RocketIcon, BeakerIcon } from 'lucide-react';
import DomainSettings from './DomainSettings';
import ABTestingVariants from './ABTestingVariants';
import ABTestingResults from './ABTestingResults';

interface PublishTabContentProps {
  pageData: any;
  setPageData: (data: any) => void;
  onPublish: () => void;
  onCreateVariant: (name: string) => void;
  onDeleteVariant: (variantId: string) => void;
  onEditVariant: (variantId: string) => void;
  onViewStats: (variantId: string) => void;
}

const PublishTabContent: React.FC<PublishTabContentProps> = ({
  pageData,
  setPageData,
  onPublish,
  onCreateVariant,
  onDeleteVariant,
  onEditVariant,
  onViewStats
}) => {
  const [activeTestTab, setActiveTestTab] = useState('variants');
  
  // Sample data for A/B testing chart
  const sampleTestData = [
    { name: 'Original', views: 542, conversions: 64 },
    { name: 'Variant A', views: 527, conversions: 81 },
    { name: 'Variant B', views: 501, conversions: 53 }
  ];

  return (
    <div className="grid grid-cols-1 gap-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Domain Settings</CardTitle>
            <CardDescription>Set up where your landing page will be hosted</CardDescription>
          </CardHeader>
          <CardContent>
            <DomainSettings 
              pageData={pageData} 
              setPageData={setPageData} 
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Publishing Options</CardTitle>
            <CardDescription>Configure additional settings before going live</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <Label className="text-base">Privacy & Data Collection</Label>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Switch id="cookie-consent" />
                  <Label htmlFor="cookie-consent">Cookie Consent Banner</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="privacy-policy" />
                  <Label htmlFor="privacy-policy">Add Privacy Policy</Label>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <Label className="text-base">Distribution</Label>
              <RadioGroup defaultValue="immediate">
                <div className="flex items-start space-x-2">
                  <RadioGroupItem value="immediate" id="immediate" />
                  <div className="grid gap-1">
                    <Label htmlFor="immediate">Publish Immediately</Label>
                    <p className="text-sm text-muted-foreground">
                      Make your landing page available as soon as you publish
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <RadioGroupItem value="schedule" id="schedule" />
                  <div className="grid gap-1">
                    <Label htmlFor="schedule">Schedule Publication</Label>
                    <p className="text-sm text-muted-foreground">
                      Choose a specific date and time to publish your landing page
                    </p>
                  </div>
                </div>
              </RadioGroup>
            </div>
            
            <div className="pt-4">
              <Button onClick={onPublish} className="w-full">
                <RocketIcon className="mr-2" />
                Publish Landing Page
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>A/B Testing</CardTitle>
          <CardDescription>Create and manage variants of your landing page to optimize conversion</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTestTab} onValueChange={setActiveTestTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="variants">
                <BeakerIcon className="mr-2 h-4 w-4" />
                Variants
              </TabsTrigger>
              <TabsTrigger value="results">
                <RocketIcon className="mr-2 h-4 w-4" />
                Results
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="variants">
              <ABTestingVariants 
                pageData={pageData}
                onCreateVariant={onCreateVariant}
                onDeleteVariant={onDeleteVariant}
                onEditVariant={onEditVariant}
                onViewStats={onViewStats}
              />
            </TabsContent>
            
            <TabsContent value="results">
              <ABTestingResults data={sampleTestData} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default PublishTabContent;
