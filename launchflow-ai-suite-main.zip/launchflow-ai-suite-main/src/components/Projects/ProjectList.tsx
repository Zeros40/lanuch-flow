
import React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Calendar, Clock, FolderKanban, MoreHorizontal, Plus, User } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

interface ProjectCardProps {
  project: {
    id: string;
    name: string;
    client: string;
    status: 'planning' | 'in-progress' | 'review' | 'completed';
    progress: number;
    team: string[];
    dueDate: string;
  };
}

const statusColors = {
  'planning': 'bg-blue-500',
  'in-progress': 'bg-amber-500',
  'review': 'bg-purple-500',
  'completed': 'bg-green-500',
};

const statusText = {
  'planning': 'Planning',
  'in-progress': 'In Progress',
  'review': 'Under Review',
  'completed': 'Completed',
};

const ProjectCard: React.FC<ProjectCardProps> = ({ project }) => {
  return (
    <Card className="card-hover">
      <CardHeader className="p-4 pb-2">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Badge variant="outline" className="text-xs capitalize px-1.5 py-0 h-5">
                <div className={cn("h-2 w-2 rounded-full mr-1", statusColors[project.status])}></div>
                {statusText[project.status]}
              </Badge>
              {project.status === 'in-progress' && (
                <Badge className="bg-amber-500 text-xs">Active</Badge>
              )}
            </div>
            <CardTitle className="text-base">{project.name}</CardTitle>
            <CardDescription className="text-sm mt-0.5">{project.client}</CardDescription>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>View details</DropdownMenuItem>
              <DropdownMenuItem>Update status</DropdownMenuItem>
              <DropdownMenuItem>Edit project</DropdownMenuItem>
              <DropdownMenuItem>View documents</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-2">
        <div className="flex items-center justify-between mb-2 text-sm text-muted-foreground">
          <div>Progress</div>
          <div>{project.progress}%</div>
        </div>
        <Progress value={project.progress} className="h-1.5 mb-4" />
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5" />
              <span>{project.dueDate}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <User className="h-3.5 w-3.5" />
              <span>{project.team.length}</span>
            </div>
          </div>
          <div className="flex -space-x-2">
            {project.team.map((member, i) => (
              <div 
                key={i}
                className="h-7 w-7 rounded-full bg-primary flex items-center justify-center text-xs text-white border-2 border-background"
              >
                {member}
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const projects = [
  {
    id: '1',
    name: 'Website Redesign',
    client: 'Acme Corporation',
    status: 'in-progress' as const,
    progress: 60,
    team: ['JS', 'TM', 'AK'],
    dueDate: 'Jun 30',
  },
  {
    id: '2',
    name: 'Marketing Strategy',
    client: 'Globex Industries',
    status: 'planning' as const,
    progress: 25,
    team: ['BM', 'SR'],
    dueDate: 'Jul 15',
  },
  {
    id: '3',
    name: 'Mobile App Development',
    client: 'Wayne Industries',
    status: 'review' as const,
    progress: 90,
    team: ['JS', 'AK', 'RN'],
    dueDate: 'Jun 22',
  },
  {
    id: '4',
    name: 'Brand Guidelines',
    client: 'Stark Enterprises',
    status: 'completed' as const,
    progress: 100,
    team: ['TM', 'SR'],
    dueDate: 'Jun 10',
  },
];

const ProjectList = () => {
  return (
    <Card className="animate-fade-in">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-xl">Projects</CardTitle>
        <Button size="sm" className="gap-1">
          <Plus className="h-4 w-4" />
          <span>Add Project</span>
        </Button>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {projects.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default ProjectList;
