
import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MoreHorizontal, Plus } from 'lucide-react';

// Sample client data
const clients = [
  {
    id: '1',
    name: 'Acme Corporation',
    contact: 'John Smith',
    email: 'john@acmecorp.com',
    status: 'active',
    projects: 3,
  },
  {
    id: '2',
    name: 'Globex Industries',
    contact: 'Sarah Johnson',
    email: 'sarah@globex.com',
    status: 'active',
    projects: 2,
  },
  {
    id: '3',
    name: 'Stark Enterprises',
    contact: 'Tony Stark',
    email: 'tony@stark.com',
    status: 'inactive',
    projects: 0,
  },
  {
    id: '4',
    name: 'Wayne Industries',
    contact: 'Bruce Wayne',
    email: 'bruce@wayne.com',
    status: 'active',
    projects: 5,
  },
  {
    id: '5',
    name: 'Initech',
    contact: 'Peter Gibbons',
    email: 'peter@initech.com',
    status: 'active',
    projects: 1,
  },
];

const ClientList = () => {
  return (
    <Card className="animate-fade-in">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-xl">Clients</CardTitle>
        <Button size="sm" className="gap-1">
          <Plus className="h-4 w-4" />
          <span>Add Client</span>
        </Button>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Projects</TableHead>
              <TableHead className="w-[60px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {clients.map((client) => (
              <TableRow key={client.id}>
                <TableCell className="font-medium">{client.name}</TableCell>
                <TableCell>
                  <div>{client.contact}</div>
                  <div className="text-sm text-muted-foreground">{client.email}</div>
                </TableCell>
                <TableCell>
                  <Badge variant={client.status === 'active' ? 'default' : 'secondary'} className="capitalize">
                    {client.status}
                  </Badge>
                </TableCell>
                <TableCell>{client.projects}</TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Open menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem>View details</DropdownMenuItem>
                      <DropdownMenuItem>Edit client</DropdownMenuItem>
                      <DropdownMenuItem>View projects</DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-destructive">Delete client</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default ClientList;
