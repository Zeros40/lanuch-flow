
import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  FileText,
  MoreHorizontal,
  Plus,
  FileCheck,
  FilePenLine,
  FileImage,
  FileSpreadsheet,
} from 'lucide-react';

const documentTypes = {
  'proposal': { icon: FilePenLine, color: 'text-blue-500' },
  'contract': { icon: FileCheck, color: 'text-green-500' },
  'presentation': { icon: FileImage, color: 'text-purple-500' },
  'report': { icon: FileSpreadsheet, color: 'text-amber-500' },
};

const documents = [
  {
    id: '1',
    name: 'Website Project Proposal',
    type: 'proposal',
    client: 'Acme Corporation',
    created: '2023-05-10',
    status: 'draft',
  },
  {
    id: '2',
    name: 'Marketing Services Contract',
    type: 'contract',
    client: 'Globex Industries',
    created: '2023-05-08',
    status: 'signed',
  },
  {
    id: '3',
    name: 'Brand Guidelines Presentation',
    type: 'presentation',
    client: 'Wayne Industries',
    created: '2023-05-05',
    status: 'approved',
  },
  {
    id: '4',
    name: 'Q1 Performance Report',
    type: 'report',
    client: 'Stark Enterprises',
    created: '2023-04-30',
    status: 'sent',
  },
  {
    id: '5',
    name: 'Software Development Contract',
    type: 'contract',
    client: 'Initech',
    created: '2023-04-28',
    status: 'draft',
  },
];

const DocumentList = () => {
  return (
    <Card className="animate-fade-in">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-xl">Documents</CardTitle>
        <Button size="sm" className="gap-1">
          <Plus className="h-4 w-4" />
          <span>Create Document</span>
        </Button>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Document</TableHead>
              <TableHead>Client</TableHead>
              <TableHead>Created</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-[60px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {documents.map((doc) => {
              const DocIcon = documentTypes[doc.type as keyof typeof documentTypes]?.icon || FileText;
              const iconColor = documentTypes[doc.type as keyof typeof documentTypes]?.color || 'text-gray-500';
              
              return (
                <TableRow key={doc.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className="bg-muted rounded p-1">
                        <DocIcon className={`h-4 w-4 ${iconColor}`} />
                      </div>
                      <div>
                        <div className="font-medium">{doc.name}</div>
                        <div className="text-xs text-muted-foreground capitalize">{doc.type}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{doc.client}</TableCell>
                  <TableCell>{new Date(doc.created).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        doc.status === 'signed' || doc.status === 'approved'
                          ? 'default'
                          : doc.status === 'sent'
                          ? 'secondary'
                          : 'outline'
                      }
                      className="capitalize"
                    >
                      {doc.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>View document</DropdownMenuItem>
                        <DropdownMenuItem>Edit document</DropdownMenuItem>
                        <DropdownMenuItem>Send to client</DropdownMenuItem>
                        <DropdownMenuItem>Download</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-destructive">Delete document</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default DocumentList;
